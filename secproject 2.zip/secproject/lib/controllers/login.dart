import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../routes/pages.dart';

class LoginController extends GetxController {
  var email = TextEditingController().obs;
  var pass = TextEditingController().obs;

  void loginUser(email, pass) async {
    await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: pass)
        .then((value) {
      Get.snackbar("Success", "User is loggedIn!!");
      Get.offAllNamed(Routes.HOME);
    }).catchError((error) {
      var a = error.code;
      var b = error.message;
      Get.snackbar("Error", "Login failed,$b!, try again later. ERRORCODE: $a");
    });
  }

  void forgetPass(email) async {
    await FirebaseAuth.instance
        .sendPasswordResetEmail(email: email)
        .then((value) {
      Get.snackbar("Success", "Password Reset request sent to your email!");
    }).catchError((error) {
      var a = error.code;
      var b = error.message;
      Get.snackbar(
          "Error", "Password reset failed,$b!, try again later. ERRORCODE: $a");
    });
  }
}
