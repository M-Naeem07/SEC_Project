import 'package:get/get.dart';
import 'package:just_audio/just_audio.dart';

class SettingsController extends GetxController {
  var music = true.obs;
  var theme = true.obs;
  final player = AudioPlayer();

  Future<void> _init() async {
    try {
      await player.setAsset('assets/images/audio.mp3');
      await player.setLoopMode(LoopMode.one);
      if (music == true) {
        player.play();
      }
    } catch (e) {
      print("Error loading audio source: $e");
    }
  }

  @override
  void onInit() {
    super.onInit();
    _init();
  }

  @override
  void dispose() {
    super.dispose();
    player.dispose();
  }
}
