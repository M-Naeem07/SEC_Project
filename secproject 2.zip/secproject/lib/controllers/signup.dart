import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../routes/pages.dart';

class SignUpController extends GetxController {
  var name = TextEditingController().obs;
  var email = TextEditingController().obs;
  var pass = TextEditingController().obs;
  void createUser(email, pass) async {
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: pass)
        .then((value) {
      Get.snackbar("Success", "User is created!!");
      Get.offAllNamed(Routes.HOME);
    }).catchError((error) {
      var a = error.code;
      var b = error.message;
      Get.snackbar(
          "Error", "Signup failed,$b!, try again later. ERRORCODE: $a");
    });
  }
}
