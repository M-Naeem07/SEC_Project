import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:secproject/models/video.dart';

class VideoController extends GetxController {
  var query = TextEditingController().obs;
  Future<List<Video>> getVideos() async {
    var vid = await FirebaseFirestore.instance.collection('videos').get();
    List<Video> videos = <Video>[];
    for (var element in vid.docs) {
      var data = element.data();
      videos.add(Video.fromJson(data));
    }
    return videos;
  }
}
