import 'package:flutter/material.dart';

Widget button(String text, Function() fn) {
  return GestureDetector(
      onTap: fn,
      child: Container(
        color: const Color(0xFF8482ED),
        child: Padding(
          padding:
              const EdgeInsets.only(left: 25.0, right: 25, top: 10, bottom: 10),
          child: Text(
            text,
            style: const TextStyle(
                fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white),
          ),
        ),
      ));
}

Widget button2(String text, Function() fn) {
  return GestureDetector(
      onTap: fn,
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white, border: Border.all(color: Colors.black)),
        // borderSide:  BorderSide(color: Colors.black, width: 1.0),
        // )),
        // color: Colors.white,
        child: Padding(
          padding:
              const EdgeInsets.only(left: 25.0, right: 25, top: 10, bottom: 10),
          child: Text(
            text,
            style: const TextStyle(
                fontSize: 28, fontWeight: FontWeight.w800, color: Colors.black),
          ),
        ),
      ));
}
