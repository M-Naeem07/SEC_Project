import 'package:flutter/material.dart';

Widget image(String path) {
  return Image.asset(
    path,
    scale: 1,
  );
}
