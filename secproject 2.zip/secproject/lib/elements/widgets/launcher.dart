import 'package:url_launcher/url_launcher.dart';

void launchingUrl(String urls) async {
  final Uri url = Uri.parse(urls);
  if (!await launchUrl(url)) throw 'Could not launch $url';
}
