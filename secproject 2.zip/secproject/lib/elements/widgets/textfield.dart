import 'package:flutter/material.dart';

Widget textField(TextEditingController controller, String name, String labels,
    TextInputType type) {
  return Column(children: [
    Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 25.0),
          child: Text(
            name,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    ),
    Padding(
      padding: const EdgeInsets.only(right: 25, left: 25, top: 5),
      child: TextField(
        controller: controller,
        maxLines: 1,
        cursorColor: Colors.black,
        obscureText: name == "Password" ? true : false,
        obscuringCharacter: '*',
        decoration: InputDecoration(
          hintText: labels,
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black, width: 1.0),
          ),
          border: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black, width: 1.0),
          ),
        ),
        keyboardType: type,
      ),
    )
  ]);
}
