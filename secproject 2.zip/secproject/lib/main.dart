import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:secproject/firebase_options.dart';
import 'package:secproject/routes/pages.dart';
import 'package:secproject/screens/signin.dart';

import 'controllers/setting.dart';
import 'elements/widgets/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  Get.put(SettingsController(), tag: 'setController', permanent: true);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SEC Project',
      theme: Themes.light,
      darkTheme: Themes.dark,
      initialRoute: Routes.START,
      getPages: Pages.routes,
      // home: const LoginPage(),
    );
  }
}
