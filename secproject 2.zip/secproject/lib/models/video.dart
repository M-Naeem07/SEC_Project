class Video {
  String? name;
  String? thumb;
  String? url;

  Video({this.name, this.thumb, this.url});

  Video.fromJson(Map<String, dynamic> json) {
    name = json['title'];
    thumb = json['thumb'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.name;
    data['thumb'] = this.thumb;
    data['url'] = this.url;
    return data;
  }
}
