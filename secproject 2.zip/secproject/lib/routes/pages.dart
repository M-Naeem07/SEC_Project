import 'package:get/get.dart';
import 'package:secproject/screens/home.dart';
import 'package:secproject/screens/settings.dart';
import 'package:secproject/screens/signup.dart';
import 'package:secproject/screens/videos.dart';

import '../screens/signin.dart';
part 'routes.dart';

class Pages {
  static final routes = [
    GetPage(
      name: Routes.START,
      page: () => const LoginPage(),
    ),
    GetPage(
      name: Routes.SIGNUP,
      page: () => const SignupPage(),
    ),
    GetPage(
      name: Routes.HOME,
      page: () => const HomePage(),
    ),
    GetPage(name: Routes.VIDEO, page: () => const VideosPage()),
    GetPage(name: Routes.SETTING, page: () => const SettingsPage())
  ];
}
