part of 'pages.dart';

abstract class Routes {
  static const START = '/';
  static const SIGNUP = '/signUp';
  static const HOME = '/home';
  static const VIDEO = '/video';
  static const SETTING = '/setting';
}
