import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:secproject/screens/videos.dart';

import '../elements/widgets/button.dart';
import '../routes/pages.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;

    var data = [
      {
        'name': 'Social Videos',
        'thumb':
            'https://explainers.in/wp-content/uploads/2018/01/Videos-The-Catalyst-For-Your-Social-Media-Marketing.png'
      },
      {
        'name': 'Poem',
        'thumb':
            'https://png.pngitem.com/pimgs/s/226-2263578_transparent-writer-clipart-spoken-poetry-background-hd-png.png'
      },
      {
        'name': 'Games',
        'thumb':
            'https://www.pngitem.com/pimgs/m/7-74487_playing-video-games-logo-hd-png-download.png'
      },
      {
        'name': 'Statistics',
        'thumb':
            'https://www.kindpng.com/picc/m/766-7662648_statistics-clipart-png-transparent-png.png'
      }
    ];
    return Container(
        color: Theme.of(context).primaryColor,
        child: SafeArea(
            child: Scaffold(
          body: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(children: [
              Row(
                children: [
                  Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height * 0.08,
                        width: MediaQuery.of(context).size.width,
                        color: Theme.of(context).primaryColor,
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 10.0),
                        child: Text(
                          'Main Menu',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 30),
                        ),
                      ),
                    ],
                  )
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.5,
                width: double.maxFinite,
                child: GridView.builder(
                  itemCount: data.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount:
                          (orientation == Orientation.portrait) ? 2 : 3),
                  itemBuilder: (BuildContext context, int index) {
                    return GestureDetector(
                      onTap: () {
                        if (data[index]['name'] == 'Social Videos') {
                          Get.toNamed(Routes.VIDEO);
                        }
                      },
                      child: Card(
                        child: GridTile(
                          footer: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              data[index]['name']!,
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 35.0),
                            child: CachedNetworkImage(
                              imageUrl: data[index]['thumb']!,
                              filterQuality: FilterQuality.high,
                              fit: BoxFit.fill,
                              placeholder: (context, url) => Center(
                                  child: CircularProgressIndicator(
                                      color: Theme.of(context).primaryColor)),
                              errorWidget: (context, url, error) =>
                                  const Icon(Icons.error),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: button("SETTINGS", () {
                  Get.toNamed(Routes.SETTING);
                }),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: button2("FEEDBACK", () {}),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: button2("LOGOUT", () {
                  FirebaseAuth.instance.signOut();
                  Get.offAllNamed(Routes.START);
                }),
              )
            ]),
          ),
        )));
  }
}
