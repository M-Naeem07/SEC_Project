import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/setting.dart';
import '../elements/widgets/index.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SettingsController>(tag: 'setController');
    return Container(
      color: Theme.of(context).primaryColor,
      child: SafeArea(
        child: Scaffold(
          body: Obx(() {
            var isMusic = controller.music.value;
            return Column(
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 30.0, bottom: 20),
                  child: Text(
                    "SETTINGS",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(
                          left: 20,
                          top: 30.0,
                          bottom: 20,
                        ),
                        child: Text(
                          "SOUND FX",
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w900),
                        ),
                      ),
                      Switch(
                        activeColor: Theme.of(context).primaryColor,
                        onChanged: (bool value) {
                          controller.music.value = value;
                          if (value == true) {
                            controller.player.play();
                          } else {
                            controller.player.pause();
                          }
                        },
                        value: isMusic,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(
                          left: 20,
                          bottom: 20,
                        ),
                        child: Text(
                          "Light Theme",
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w900),
                        ),
                      ),
                      Switch(
                        activeColor: Theme.of(context).primaryColor,
                        onChanged: (bool value) {
                          controller.theme.value = value;
                          if (value == true) {
                            Get.changeThemeMode(ThemeMode.light);
                          } else {
                            Get.changeThemeMode(ThemeMode.dark);
                          }
                        },
                        value: controller.theme.value,
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: button2("BACK", () {
                        Get.back();
                      }),
                    ),
                  ],
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
