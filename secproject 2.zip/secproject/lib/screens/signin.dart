import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';

import '../controllers/login.dart';
import '../elements/widgets/index.dart';
import '../routes/pages.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LoginController controller =
        Get.put(LoginController(), tag: 'loginController');

    return Container(
      color: Theme.of(context).primaryColor,
      child: SafeArea(
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                image('assets/images/bg.png'),
                textField(controller.email.value, "Email", "Type your email?",
                    TextInputType.emailAddress),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: textField(controller.pass.value, "Password",
                      "Type your password?", TextInputType.visiblePassword),
                ),
                GestureDetector(
                  onTap: () {
                    if (controller.email.value.text.isEmpty) {
                      Get.snackbar("Error", "Email field is empty!!");
                      return;
                    }
                    controller.forgetPass(controller.email.value.text);
                  },
                  child: Padding(
                    padding:
                        const EdgeInsets.only(right: 30.0, top: 10, bottom: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: const [
                        Text(
                          'forget password?',
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  ),
                ),
                button('LOGIN', () {
                  if (controller.email.value.text.isEmpty) {
                    Get.snackbar("Error", "Email field is empty!!");
                    return;
                  }
                  if (controller.pass.value.text.isEmpty) {
                    Get.snackbar("Error", "Password field is empty!!");
                    return;
                  }

                  controller.loginUser(
                      controller.email.value.text, controller.pass.value.text);
                }),
                GestureDetector(
                  onTap: () {
                    Get.toNamed(Routes.SIGNUP);
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(
                        right: 30.0, top: 10, bottom: 20, left: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text(
                          'don\'t have account?',
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
