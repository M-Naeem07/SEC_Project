import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:secproject/controllers/signup.dart';

import '../elements/widgets/index.dart';

class SignupPage extends StatelessWidget {
  const SignupPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final SignUpController controller =
        Get.put(SignUpController(), tag: 'signUpController');

    return Container(
      color: Theme.of(context).primaryColor,
      child: SafeArea(
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                image('assets/images/bg.png'),
                textField(controller.name.value, "Name", "Type your name?",
                    TextInputType.name),
                textField(controller.email.value, "Email", "Type your email?",
                    TextInputType.emailAddress),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: textField(controller.pass.value, "Password",
                      "Type your password?", TextInputType.visiblePassword),
                ),
                GestureDetector(
                  onTap: () {},
                  child: Padding(
                    padding: const EdgeInsets.only(
                        right: 30.0, top: 10, bottom: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: const [
                        Text(
                          '',
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  ),
                ),
                button('SIGNUP', () {
                  if (controller.name.value.text.isEmpty) {
                    Get.snackbar("Error", "Name field is empty!!");
                    return;
                  }
                  if (controller.email.value.text.isEmpty) {
                    Get.snackbar("Error", "Email field is empty!!");
                    return;
                  }
                  if (controller.pass.value.text.isEmpty) {
                    Get.snackbar("Error", "Password field is empty!!");
                    return;
                  }

                  controller.createUser(controller.email.value.text,
                      controller.pass.value.text);
                }),
                GestureDetector(
                  onTap: () {
                    Get.back();
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(
                        right: 30.0, top: 10, bottom: 20, left: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text(
                          'have account?',
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
