import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:secproject/models/video.dart';
import '../elements/widgets/index.dart';

import '../controllers/video.dart';

class VideosPage extends StatelessWidget {
  const VideosPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final VideoController controller =
        Get.put(VideoController(), tag: 'videoController');
    final orientation = MediaQuery.of(context).orientation;

    return Container(
      color: Theme.of(context).primaryColor,
      child: SafeArea(
        child: Scaffold(
          body: Obx(() {
            var query = controller.query.value;
            return Column(
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 30.0, bottom: 20),
                  child: Text(
                    "SEARCH VIDEOS",
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                  ),
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: SizedBox(
                        width: 400,
                        height: 80,
                        child: Theme(
                          data: ThemeData(
                              primaryColor: Theme.of(context).primaryColor,
                              iconTheme: IconThemeData(
                                  color: Theme.of(context).primaryColor)),
                          child: TextField(
                            controller: controller.query.value,
                            autocorrect: false,
                            decoration: InputDecoration(
                                hintText: "Search your video?",
                                focusedBorder: const OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 1.0),
                                ),
                                border: const OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 1.0),
                                ),
                                prefixIcon: Icon(
                                  Icons.search,
                                  color: Theme.of(context).primaryColor,
                                ),
                                focusColor: Theme.of(context).primaryColor,
                                suffixIcon: GestureDetector(
                                  child: Icon(
                                    Icons.close,
                                    color: Theme.of(context).primaryColor,
                                  ),
                                )),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                FutureBuilder(
                    future: controller.getVideos(),
                    builder: ((context, AsyncSnapshot<List<Video>> snapshot) {
                      if (snapshot.hasData && snapshot.data != null) {
                        var data = snapshot.data;

                        if (data!.isEmpty) {
                          return const Center(
                            child: Text("No Video Found"),
                          );
                        }
                        if (query.text.isNotEmpty) {
                          data = snapshot.data!
                              .where((element) => element.name == query)
                              .toList();
                        }

                        return SizedBox(
                          height: MediaQuery.of(context).size.height * 0.4,
                          width: double.maxFinite,
                          child: GridView.builder(
                            itemCount: data.length,
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount:
                                        (orientation == Orientation.portrait)
                                            ? 2
                                            : 3),
                            itemBuilder: (BuildContext context, int index) {
                              return GestureDetector(
                                onTap: () {
                                  launchingUrl(data![index].url!);
                                },
                                child: Card(
                                  child: GridTile(
                                    footer: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        data![index].name!,
                                        style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 35.0),
                                      child: CachedNetworkImage(
                                        imageUrl: data[index].thumb!,
                                        filterQuality: FilterQuality.high,
                                        fit: BoxFit.fill,
                                        placeholder: (context, url) => Center(
                                            child: CircularProgressIndicator(
                                                color: Theme.of(context)
                                                    .primaryColor)),
                                        errorWidget: (context, url, error) =>
                                            const Icon(Icons.error),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }
                      return Center(
                          child: CircularProgressIndicator(
                              color: Theme.of(context).primaryColor));
                    })),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: button2("BACK", () {
                        Get.back();
                      }),
                    ),
                  ],
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
